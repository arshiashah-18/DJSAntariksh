import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist


class MinimalSubscriber(Node):

    def __init__(self):
        super().__init__('minimal_subscriber')
        self.subscription1 = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.listener_callback1,
            10)
        self.subscription1
        self.subscription2 = self.create_subscription(
            Pose,
            '/turtle2/pose',
            self.listener_callback2,
            10)
        self.subscription2
        self.subscription3 = self.create_subscription(
            Pose,
            '/turtle3/pose',
            self.listener_callback3,
            10)
        self.subscription3

        self.cmd_vel_publisher1 = self.create_publisher(Twist,'/turtle1/cmd_vel',10)
        self.cmd_vel_publisher2 = self.create_publisher(Twist,'/turtle2/cmd_vel',10)
        self.cmd_vel_publisher3 = self.create_publisher(Twist,'/turtle3/cmd_vel',10)

        self.counter=1
        
        timer_period=0.5

        self.beg_linear1=float(-1)
        self.beg_angular1=float(1)
        self.beg_linear2=float(-1)
        self.beg_angular2=float(1)
        self.beg_linear3=float(-0.5)
        self.beg_angular3=float(0.5)
        
        self.timer =self.create_timer(timer_period,self.publisher_change)
        

    def listener_callback1(self,Pose):
     
        self.turtle1_x=Pose.x
        self.turtle1_y=Pose.y
       


    def listener_callback2(self,Pose):
        
        self.turtle2_x=Pose.x
        self.turtle2_y=Pose.y
       

    def listener_callback3(self,Pose):
      
        self.turtle3_x=Pose.x
        self.turtle3_y=Pose.y
       
    

    def publisher_change(self): 

        twist_msg1=Twist()
        twist_msg2=Twist()
        twist_msg3=Twist()

       
        




        if self.counter ==1:
            twist_msg1.linear.x=self.beg_linear1
            twist_msg1.angular.z=self.beg_angular1
            twist_msg2.linear.x=self.beg_linear2
            twist_msg2.angular.z=self.beg_angular2
            twist_msg3.linear.x=self.beg_linear3
            twist_msg3.angular.z=self.beg_angular3

            self.cmd_vel_publisher1.publish(twist_msg1)
            self.cmd_vel_publisher2.publish(twist_msg2)
            self.cmd_vel_publisher3.publish(twist_msg3)

        
        if (round(self.turtle1_x)==round(self.turtle2_x)) and (round(self.turtle1_y)==round(self.turtle2_y)):
            self.counter +=1
            self.beg_linear1*=-1
            self.beg_angular1*=-1
            self.beg_linear2*=-1
            self.beg_angular2*=-1

        if (round(self.turtle3_x)==round(self.turtle2_x)) and (round(self.turtle3_y)==round(self.turtle2_y)):
            self.counter +=1
            if self.counter==2:
                self.beg_linear3*=2
                self.beg_angular3*=2
            
            self.beg_linear3*=-1
            self.beg_angular3*=-1
            self.beg_linear2*=-1
            self.beg_angular2*=-1

        twist_msg1.linear.x=self.beg_linear1
        twist_msg1.angular.z=self.beg_angular1
        twist_msg2.linear.x=self.beg_linear2
        twist_msg2.angular.z=self.beg_angular2
        twist_msg3.linear.x=self.beg_linear3
        twist_msg3.angular.z=self.beg_angular3
        self.cmd_vel_publisher1.publish(twist_msg1)
        self.cmd_vel_publisher2.publish(twist_msg2)
        self.cmd_vel_publisher3.publish(twist_msg3)

       

def main(args=None):
    rclpy.init(args=args)

    minimal_subscriber = MinimalSubscriber()

    rclpy.spin(minimal_subscriber)

 
    minimal_subscriber.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
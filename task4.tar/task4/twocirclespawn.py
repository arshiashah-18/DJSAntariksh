from turtlesim.srv import Spawn
import rclpy
from rclpy.node import Node
import math

class MinimalClientAsync(Node):

    def __init__(self):
        super().__init__('minimal_client_async')
        self.cli1 = self.create_client(Spawn, '/spawn')
        self.cli2 = self.create_client(Spawn, '/spawn')
        self.cli3 = self.create_client(Spawn, '/spawn')
        while not self.cli1.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.req = Spawn.Request()

    def send_request1(self):
        self.req.x = float(5)
        self.req.y = float(2)
        self.req.theta = float(math.pi)
        self.req.name = 'turtle1'
        return self.cli1.call_async(self.req)

    def send_request2(self):
        self.req.x = float(5)
        self.req.y = float(4)
        self.req.theta = float(math.pi*2)
        self.req.name = 'turtle2'
        return self.cli1.call_async(self.req)

    def send_request3(self):
        self.req.x = float(5)
        self.req.y = float(6)
        self.req.theta = float(math.pi*2)
        self.req.name = 'turtle3'
        return self.cli1.call_async(self.req)
        


def main():
    rclpy.init()

    minimal_client = MinimalClientAsync()
    future1 = minimal_client.send_request1()
    response = future1.result()
    rclpy.spin_until_future_complete(minimal_client, future1)
    minimal_client.get_logger().info(
        'spawned' )
    future2 = minimal_client.send_request2()
    rclpy.spin_until_future_complete(minimal_client, future2)
    response = future2.result()
    minimal_client.get_logger().info(
        'spawned' )
    future3 = minimal_client.send_request3()
    response = future3.result()
    rclpy.spin_until_future_complete(minimal_client, future3)
    minimal_client.get_logger().info(
        'spawned' )

    minimal_client.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class helloworld_subscriber(Node):
    def __init__(self):
        super().__init__('helloworld_subscriber')
        self.hello_msg = None
        self.world_msg = None
        self.publisher_ = self.create_publisher(String, '/helloworld', 10)

        self.subscriber_hello = self.create_subscription(
            String,
            '/hello_topic',
            self.hello_callback,
            10
        )

        self.subscriber_world = self.create_subscription(
            String,
            '/world_topic',
            self.world_callback,
            10
        )
        timer_period = 0.5
        self.timer = self.create_timer(timer_period, self.publish_combined_message)
        self.i = 0
        

    def hello_callback(self, msg):
        self.hello_msg = msg.data
        self.publish_combined_message()

    def world_callback(self, msg):
        self.world_msg = msg.data
        self.publish_combined_message()

    def publish_combined_message(self):
         combined_msg = String()
         combined_msg.data   = f'{self.hello_msg} {self.world_msg}'
         self.publisher_.publish(combined_msg)
         self.get_logger().info(f'Publishing : {combined_msg.data}')
         self.i+=1

def main(args=None):
    rclpy.init(args=args)
    node = helloworld_subscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
